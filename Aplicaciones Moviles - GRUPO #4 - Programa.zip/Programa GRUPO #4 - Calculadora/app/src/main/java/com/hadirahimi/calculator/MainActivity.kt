package com.hadirahimi.calculator

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.WindowManager
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.children
import com.hadirahimi.calculator.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity()
{
    // Binding para el acceso a los elementos de la interfaz de usuario
    private lateinit var binding : ActivityMainBinding

    // Variables para almacenar los números y operadores
    private var firstnumber = ""
    private var currentNumber = ""
    private var currentOperator = ""
    private var result = ""

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState : Bundle?)
    {
        super.onCreate(savedInstanceState)
        // Inicialización del binding con el layout de la actividad
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Configura la pantalla para usar todo el espacio disponible
        window.setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS)

        // Inicializa las vistas y configura los listeners para los botones
        binding.apply {
            // Obtiene todos los botones del layout principal
            binding.layoutMain.children.filterIsInstance<Button>().forEach { button ->
                // Configura el listener de clic para cada botón
                button.setOnClickListener {
                    // Obtiene el texto del botón clicado
                    val buttonText = button.text.toString()

                    when {
                        // Si el botón es un número, actualiza el número actual o el primer número
                        buttonText.matches(Regex("[0-9]")) -> {
                            if(currentOperator.isEmpty())
                            {
                                firstnumber += buttonText
                                tvResult.text = firstnumber
                            } else {
                                currentNumber += buttonText
                                tvResult.text = currentNumber
                            }
                        }
                        // Si el botón es un operador (+, -, *, /), actualiza el operador actual
                        buttonText.matches(Regex("[+\\-*/]")) -> {
                            currentNumber = ""
                            if (tvResult.text.toString().isNotEmpty())
                            {
                                currentOperator = buttonText
                                tvResult.text = "0"
                            }
                        }
                        // Si el botón es el signo igual (=), evalúa la expresión actual
                        buttonText == "=" -> {
                            if (currentNumber.isNotEmpty() && currentOperator.isNotEmpty())
                            {
                                tvFormula.text = "$firstnumber$currentOperator$currentNumber"
                                result = evaluateExpression(firstnumber, currentNumber, currentOperator)
                                firstnumber = result
                                tvResult.text = result
                            }
                        }
                        // Si el botón es el punto (.), añade un punto decimal al número actual
                        buttonText == "." -> {
                            if(currentOperator.isEmpty())
                            {
                                if (!firstnumber.contains("."))
                                {
                                    if(firstnumber.isEmpty()) firstnumber += "0$buttonText"
                                    else firstnumber += buttonText
                                    tvResult.text = firstnumber
                                }
                            } else {
                                if (!currentNumber.contains("."))
                                {
                                    if(currentNumber.isEmpty()) currentNumber += "0$buttonText"
                                    else currentNumber += buttonText
                                    tvResult.text = currentNumber
                                }
                            }
                        }
                        // Si el botón es "C", limpia todos los valores
                        buttonText == "C" -> {
                            currentNumber = ""
                            firstnumber = ""
                            currentOperator = ""
                            tvResult.text = "0"
                            tvFormula.text = ""
                        }
                    }
                }
            }
        }
    }

    // Función para evaluar la expresión matemática basada en el operador
    private fun evaluateExpression(firstNumber: String, secondNumber: String, operator: String): String
    {
        val num1 = firstNumber.toDouble()
        val num2 = secondNumber.toDouble()
        return when(operator)
        {
            "+" -> (num1 + num2).toString()
            "-" -> (num1 - num2).toString()
            "*" -> (num1 * num2).toString()
            "/" -> (num1 / num2).toString()
            else -> ""
        }
    }
}
